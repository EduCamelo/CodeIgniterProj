var botao = document.getElementById('deletou');
botao.addEventListener('click', function () {
    window.alert('Atividade deletada com sucesso.');
});
